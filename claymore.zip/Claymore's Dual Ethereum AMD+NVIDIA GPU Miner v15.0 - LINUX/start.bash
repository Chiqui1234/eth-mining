./ethdcrminer64 -epool us1.ethpool.org:3333 -ewal 0x360d6f9efea21c82d341504366fd1c2eeea8fa9d -epsw x -dpool stratum+tcp://dcr.suprnova.cc:3252 -dwal Redhex.my -dpsw x
