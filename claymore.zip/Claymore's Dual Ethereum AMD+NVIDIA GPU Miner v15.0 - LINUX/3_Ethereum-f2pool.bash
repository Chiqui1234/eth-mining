./ethdcrminer64 -epool eth.f2pool.com:6688 -ewal dualminerru -eworker dualminerru -epsw x -mode 1 -r 0 -dbg -1 -mport 0 -etha 0 -retrydelay 1 -ftime 55 -tt 79 -ttli 77 -tstop 89 -fanmin 30 -asm 2 -allpools 1


